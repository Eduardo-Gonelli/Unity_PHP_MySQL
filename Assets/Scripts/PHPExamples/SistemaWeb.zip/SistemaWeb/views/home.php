<h1>Cadastramento de Jogadores</h1>
<p>Bem vindo <?php echo isset($_SESSION['jogador_nome']) ? $_SESSION['jogador_nome']:"";?></p>
<p>Utilize o botão "Jogadores" para gerenciar os jogadores ou clique em "Sair" para encerrar a sessão</p>