<h2>Faça o login para acessar o sistema</h2>
<?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo $_SESSION['error']; ?>
        <?php unset($_SESSION['error']); ?>
    </div>
<?php endif; ?>
<hr>
<form action="?action=login_action" method="post">    
    <label class="badge badge-secondary" for="email">E-mail</label>
    <input  class="form-control" type="email" name="email" id="email" required><br>
    <label class="badge badge-secondary" for="password">Senha</label>
    <input  class="form-control" type="password" name="password" id="password" required><br>    
    <input type="submit" class="btn btn-success" value="Acessar">
</form>
<br>
<p class="text-center">Se não possuir uma conta, crie uma nova <a href="?action=registrar">aqui!</a></p>