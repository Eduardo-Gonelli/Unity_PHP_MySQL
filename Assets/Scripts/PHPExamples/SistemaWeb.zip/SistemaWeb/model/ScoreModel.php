<?php

include_once 'DB.php';

class ScoreModel {
    private $conn;
    private $table_name = "scores";

    public $id;
    public $jogador_id;
    public $score;    
    public $created_at;
    public $updated_at;
    // Adicione outras propriedades conforme necessário

    public function __construct() {
        $database = new DB();
        $this->conn = $database->getConnection();
    }

    public function save_score($data){
        // associa os dados recebidos
        $this->jogador_id = $data['jogador_id'];
        $this->score = $data['score'];
        $this->created_at = date('Y-m-d H:i:s');
        $this->updated_at = date('Y-m-d H:i:s');

        // trata os dados para evitar sql injection
        $this->jogador_id = htmlspecialchars(strip_tags($this->jogador_id));
        $this->score = htmlspecialchars(strip_tags($this->score));
        $this->created_at = htmlspecialchars(strip_tags($this->created_at));
        $this->updated_at = htmlspecialchars(strip_tags($this->updated_at));

        // verifica se já não há pontuação para o jogador
        $query = "SELECT * FROM " . $this->table_name . " WHERE jogador_id=:jogador_id";
        $stmt = $this->conn->prepare($query);        
        $stmt->bindParam(":jogador_id", $this->jogador_id);
        $stmt->execute();
        $num = $stmt->rowCount();

        // se já houver pontuação, atualiza o score
        if ($num > 0) {
            $query = "UPDATE " . $this->table_name . " SET score=:score, updated_at=:updated_at WHERE jogador_id=:jogador_id";
            $stmt = $this->conn->prepare($query);

            // associa os valores recebidos aos parâmetros da query
            $stmt->bindParam(":score", $this->score);
            $stmt->bindParam(":updated_at", $this->updated_at);
            $stmt->bindParam(":jogador_id", $this->jogador_id);
            if ($stmt->execute()) {
                return true;
            }
        } else {
            // se não houver pontuação, insere o score
            $query = "INSERT INTO " . $this->table_name . " SET jogador_id=:jogador_id, score=:score, created_at=:created_at, updated_at=:updated_at";
            $stmt = $this->conn->prepare($query);

            // associa os valores recebidos aos parâmetros da query
            $stmt->bindParam(":jogador_id", $this->jogador_id);
            $stmt->bindParam(":score", $this->score);
            $stmt->bindParam(":created_at", $this->created_at);
            $stmt->bindParam(":updated_at", $this->updated_at);
            if ($stmt->execute()) {
                return true;
            }
        }
    }

    public function load_score(){
        $query = "SELECT s.id, s.jogador_id, j.name as jogador_name, s.score, s.updated_at 
                  FROM scores s
                  JOIN jogadores j ON s.jogador_id = j.id
                  ORDER BY s.score DESC 
                  LIMIT 10";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $num = $stmt->rowCount();
        
        if ($num > 0) {
            $scores = array();
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                extract($row);
                $score_item = array(
                    "id" => $id,
                    "jogador_id" => $jogador_id,
                    "name" => $jogador_name,
                    "score" => $score,
                    "updated_at" => $updated_at
                );
                array_push($scores, $score_item);
            }
            return $scores;
        } else {
            return false;
        }
    }
    
}