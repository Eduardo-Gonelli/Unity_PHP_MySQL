<?php
session_start();
require('controller/JogadorController.php');
require('controller/ScoreController.php');
$action = isset($_GET['action']) ? $_GET['action'] : 'home';

$controller = new JogadorController();
$score_controller = new ScoreController();
// verifica se o usuário está logado
$token = isset($_SESSION['token']) ? $_SESSION['token'] : null;

// se não estiver logado, redireciona para a página de login
$actionsWithoutLogin = ['login', 'registrar', 'login_action', 'insert', 'api_login', 'api_get_score', 'api_save_score', 'api_check_token'];

if ($token == null && !in_array($action, $actionsWithoutLogin)) {
    header('Location: ?action=login');
    exit();
} else if (!$controller->esta_logado() && !in_array($action, $actionsWithoutLogin)) {
    header('Location: ?action=login');
    exit();
}


switch ($action) {
    case 'home':
        $controller->home();
        break;

    case 'listar':
        $controller->listar();
        break;

    case 'inserir':
        $controller->inserir_form();
        break;

    case 'insert':
        // recebe o post com os dados do jogador e envia para o controller
        $data['name'] = filter_input(INPUT_POST, 'name');
        $data['email'] = filter_input(INPUT_POST, 'email');
        // converter o password para hash bcrypt
        $data['password'] = password_hash(filter_input(INPUT_POST, 'password'), PASSWORD_DEFAULT);
        $jogador = $controller->inserir($data);
        break;

    case 'editar':
        $id = $_GET['id'];
        if ($id != '') {
            $controller->editar_form($id);
        }

        break;

    case 'update':
        // recebe o post com os dados do jogador e envia para o controller
        $data['id'] = filter_input(INPUT_GET, 'id');
        $data['name'] = filter_input(INPUT_POST, 'name');
        $data['email'] = filter_input(INPUT_POST, 'email');
        // converter o password para hash bcrypt
        if (!empty($_POST['password'])) {
            $data['password'] = password_hash(filter_input(INPUT_POST, 'password'), PASSWORD_DEFAULT);
        }
        $jogador = $controller->atualizar($data);
        break;

    case 'deletar':
        $id = isset($_GET['id']) ? $_GET['id'] : null;
        if ($id != null) {
            $controller->deletar($id);
        }
        break;

    case 'login':
        $controller->login();
        break;

    case 'registrar':
        $controller->registrar();
        break;

    case 'login_action':
        $data['email'] = filter_input(INPUT_POST, 'email');
        $data['password'] = filter_input(INPUT_POST, 'password');
        $controller->login_action($data);
        break;

    case 'sair':
        $controller->sair();
        break;

    case 'api_login':
        header('Content-Type: application/json; charset=utf-8');
        $data['email'] = filter_input(INPUT_POST, 'email');
        $data['password'] = filter_input(INPUT_POST, 'password');
        $data['token'] = filter_input(INPUT_POST, 'token');
        $controller->api_login($data);
        break;

    case 'api_save_score':
        header('Content-Type: application/json; charset=utf-8');
        $data['jogador_id'] = filter_input(INPUT_POST, 'jogador_id');
        $data['score'] = filter_input(INPUT_POST, 'score');
        $data['token'] = filter_input(INPUT_POST, 'token');
        $score_controller->save_score($data);
        break;

    case 'api_get_score':
        header('Content-Type: application/json; charset=utf-8');
        $data['jogador_id'] = filter_input(INPUT_POST, 'jogador_id');
        $data['token'] = filter_input(INPUT_POST, 'token');
        $score_controller->load_scores($data);
        break;

    case 'api_check_token':
        header('Content-Type: application/json; charset=utf-8');
        $data['jogador_id'] = filter_input(INPUT_POST, 'jogador_id');
        $data['token'] = filter_input(INPUT_POST, 'token');
        $controller->api_check_token($data);
        break;

    default:
        echo "Ação não reconhecida.";
        break;
}
