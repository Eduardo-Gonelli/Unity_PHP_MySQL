// JavaScript para adicionar a lógica da tabela

// Função para atualizar a tabela quando o mês ou o ano for selecionado
function updateTable() {
    const month = document.getElementById("month").value;
    const year = document.getElementById("year").value;
    const headerRow = document.getElementById("headerRow");
    const tableBody = document.getElementById("tableBody");
  
    // Limpar colunas de dias anteriores
    while (headerRow.cells.length > 1) {
      headerRow.deleteCell(1);
    }
  
    // Obter o número de dias no mês selecionado
    const daysInMonth = new Date(year, month, 0).getDate();
  
    // Adicionar células de dia ao cabeçalho
    for (let i = 1; i <= daysInMonth; i++) {
      const cell = headerRow.insertCell(-1);
      cell.innerText = i;
      if (new Date(year, month - 1, i).getDay() === 0) {
        cell.classList.add("sunday");
      }
    }
    // Adicionar coluna para 'Dias Trabalhados'
    const totalCell = headerRow.insertCell(-1);
    totalCell.innerText = "Dias Trabalhados";
  }
  
  // Função para adicionar um novo colaborador à tabela
  function addRow() {
    const tableBody = document.getElementById("tableBody");
    const newRow = tableBody.insertRow(-1);
    const nameCell = newRow.insertCell(0);
    nameCell.contentEditable = "true";
    nameCell.innerText = "Novo Colaborador";
  
    const daysInMonth = document.getElementById("headerRow").cells.length - 2;
  
    // Adicionar células de dia para o novo colaborador
    for (let i = 1; i <= daysInMonth; i++) {
      const cell = newRow.insertCell(-1);
      cell.contentEditable = "true";
      if (new Date(year, month - 1, i).getDay() === 0) {
        cell.classList.add("sunday");
        cell.contentEditable = "false";
      }
    }
    // Adicionar célula para 'Dias Trabalhados'
    const totalCell = newRow.insertCell(-1);
    totalCell.innerText = 0;
  
    // Adicionar botão de exclusão
    const deleteCell = newRow.insertCell(-1);
    const deleteButton = document.createElement("button");
    deleteButton.innerText = "Excluir";
    deleteButton.onclick = function() { newRow.remove(); };
    deleteCell.appendChild(deleteButton);
  }
  
  // Função para contar os dias trabalhados para cada colaborador
  function countDays(row) {
    let count = 0;
    for (let i = 1; i < row.cells.length - 1; i++) {
      if (row.cells[i].innerText === "X") {
        count++;
      }
    }
    row.cells[row.cells.length - 1].innerText = count;
  }
  
  // Código para inicializar e adicionar eventos
  document.addEventListener("DOMContentLoaded", function() {
    // Inicializar a tabela
    updateTable();
  
    // Adicionar evento para atualizar a tabela quando o mês ou o ano for alterado
    document.getElementById("month").addEventListener("change", updateTable);
    document.getElementById("year").addEventListener("change", updateTable);
  
    // Adicionar evento para o botão que adiciona novos colaboradores
    document.getElementById("addRow").addEventListener("click", addRow);
  });