<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<title>Gerenciamento de Usuários</title>
	<meta charset="UTF-8">
	<? // importa o bootstrap ?>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<? // importa o datatable para ajustar os dados como tabela mais facilmente ?>
	<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	<? // importa a folha de estilo em cascata criada para este exemplo ?>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<header>
		<div class="container"> <? // a classe container faz parte do bootstrap ?>
			<a href="?action=home"><img src="img/logo.png" title="Logo" alt="Logo"></a>
			<div id="menu">
			<?php if(isset($_SESSION['token'])): ?>	
				<a href="?action=listar">Jogadores</a>									
				<a href="?action=sair">Sair</a>
				<?php endif; ?>
			</div>		
		</div>
		<br>		
	</header>
	<div id="conteudo" class="container">
	