<?php
date_default_timezone_set('America/Sao_Paulo');
class DB {
    // definição do horário padrão para o Brasil
    private $host = 'localhost';
    private $db_name = 'unity_gamers';
    private $username = 'unity_gsd';
    private $password = 'S5qZ/ki*7ssK_b4Y';
    public $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }

        return $this->conn;
    }
}
