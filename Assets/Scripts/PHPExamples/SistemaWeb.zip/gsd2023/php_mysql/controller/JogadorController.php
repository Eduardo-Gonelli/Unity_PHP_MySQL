<?php
require('model/Jogador.php');
require('model/Token.php');
class JogadorController {

    private $model;
    private $token;
    // construct
    public function __construct() {
        $this->model = new Jogador();
        $this->token = new Token();        
        // instancia um novo jogador
    }

    public function home(){
        include 'views/partials/header.php'; // Inclui o cabeçalho da página
        include 'views/home.php';
        include 'views/partials/footer.php'; // Inclui o rodapé da página
    }

    public function listar() {
        $jogadores = $this->model->listar_jogadores(); // $jogadores é usado na view listar
        include 'views/partials/header.php'; // Inclui o cabeçalho da página
        include 'views/jogadores/listar.php';
        include 'views/partials/footer.php'; // Inclui o rodapé da página            
    }

    public function inserir_form() {
        include 'views/partials/header.php'; // Inclui o cabeçalho da página
        include 'views/jogadores/inserir.php';
        include 'views/partials/footer.php'; // Inclui o rodapé da página
    }

    public function inserir($data) {
        $jogador = $this->model->inserir_jogador($data);        
        // se inseriu o jogador com sucesso, retorna para a view listar, senão, retorna para a view inserir
        if ($jogador) {
            header('Location: ?action=listar');
        } else {
            header('Location: ?action=inserir');
        }
    }

    public function editar_form($id)
    {        
        $jogador = $this->model->pegar_jogador($id); // $jogador é usado na view editar
        include 'views/partials/header.php'; // Inclui o cabeçalho da página
        include 'views/jogadores/editar.php';
        include 'views/partials/footer.php'; // Inclui o rodapé da página
    }

    public function atualizar($data){
        $jogador = $this->model->atualizar_jogador($data);
        // se atualizou o jogador com sucesso, retorna para a view listar, senão, retorna para a view editar
        if ($jogador) {
            header('Location: ?action=listar');
        } else {
            header('Location: ?action=editar'.'&id='.$data['id']);
        }
    }

    public function deletar($id){
        $this->model->deletar_jogador($id);        
        header('Location: ?action=listar');
    }

    public function login(){
        include 'views/partials/header.php'; 
        include 'views/jogadores/login.php';
        include 'views/partials/footer.php'; 
    }

    public function registrar(){
        include 'views/partials/header.php'; 
        include 'views/jogadores/registrar.php';
        include 'views/partials/footer.php'; 
    }

    public function login_action($data){
        $jogador = $this->model->pegar_jogador_por_email($data['email'], $data['password']);
        if($jogador){
            $dados = array(
                'jogador_id' => $jogador['id'],
                'token' => md5($data['email'].uniqid(rand(), true))
            );
            // cria um token para o jogador
            $token_valor = $this->token->inserir_token($dados);
            // se o token foi criado com sucesso, redireciona para a home
            if($token_valor){
                // para evitar session fixation
                session_regenerate_id(true); 
                // grava o token na sessão                               
                $_SESSION['jogador_id'] = $jogador['id'];               
                $_SESSION['jogador_nome'] = $jogador['name'];
                $_SESSION['token'] = $dados['token'];                
                header('Location: ?action=home');
            } else {
                $_SESSION['error'] = "Erro ao criar o token!";
                header('Location: ?action=login');
            }
        } else {
            $_SESSION['error'] = "E-mail ou senha inválidos!";
            header('Location: ?action=login');
        }
    }

    public function esta_logado(){
        if($this->token->verificar_token()){
            return true;
        } else {
            return false;
        }
    }

    public function sair(){
        // remove o token da sessão
        unset($_SESSION['token']);
        // redireciona para a página de login
        session_destroy();
        header('Location: ?action=login');
    }

    public function api_login($data){
        $jogador = $this->model->pegar_jogador_por_email($data['email'], $data['password']);
        if($jogador){
            $dados = array(
                'jogador_id' => $jogador['id'],
                'token' => $data['token']
            );
            $token_valor = $this->token->inserir_token($dados);
            // se o token foi criado com sucesso, redireciona para a home
            if($token_valor){
                // para evitar session fixation
                session_regenerate_id(true); 
                echo json_encode($jogador);
                exit;
            } else {                
                echo json_encode(array('error' => 'Erro ao criar o token!'));
            }
        } else {
            echo json_encode(array('error' => 'E-mail ou senha invalidos!'));
        }
    }

    public function api_check_token($data){
        $_SESSION['token'] = $data['token'];
        $_SESSION['jogador_id'] = $data['jogador_id'];
        $token = $this->token->verificar_token();
        if($token){
            echo json_encode(array('success' => 'Token valido!'));
        } else {
            echo json_encode(array('error' => 'Token invalido!'));
        }
    }
}




