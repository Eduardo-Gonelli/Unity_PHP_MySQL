<?php
require('model/ScoreModel.php');


class ScoreController
{

    private $score_model;
    private $token;
    // construct
    public function __construct()
    {
        $this->score_model = new ScoreModel();
        $this->token = new Token();
    }

    public function load_scores($data)
    {
        $_SESSION['token'] = $data['token'];
        $_SESSION['jogador_id'] = $data['jogador_id'];
        $token = $this->token->verificar_token();
        if ($token) {
            // carrega todas as pontuações através da model score
            $scores = $this->score_model->load_score();
            if ($scores) {
                // se carregou com sucesso, retorna as pontuações no formato json
                echo json_encode($scores);
            } else {
                echo json_encode(array('error' => 'Não foi possivel carregar as pontuações'));
            }
        } else {
            echo json_encode(array('error' => 'Token invalido!'));
        }
    }

    public function save_score($data)
    {
        $_SESSION['token'] = $data['token'];
        $_SESSION['jogador_id'] = $data['jogador_id'];
        $token = $this->token->verificar_token();
        if ($token) {
            $resultado = $this->score_model->save_score($data);
            if ($resultado) {
                echo json_encode(array('success' => 'Pontos salvos com sucesso'));
            } else {
                echo json_encode(array('error' => 'Nao foi possivel salvar os pontos'));
            }
        } else {
            echo json_encode(array('error' => 'Token invalido!'));
        }
    }
}
