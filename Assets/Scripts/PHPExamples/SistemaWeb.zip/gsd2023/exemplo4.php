<?php
declare(strict_types=1);
// com tipagem obrigatória
function addNumbers(int $a, int $b){
    return $a + $b;
}
// apresenta erro na chamada
echo addNumbers(5, "15");
// sem erro na chamada
echo addNumbers(5, 15);
?>
