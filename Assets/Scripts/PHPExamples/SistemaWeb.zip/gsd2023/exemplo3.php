<?php
// recebe um array de números e retorna
// um array com o menor e o maior número
function getMinMax($arr) {
    return [min($arr), max($arr)];
}
list($min, $max) = getMinMax([1, 2, 3, 4, 5]);
echo "Min: $min, Max: $max"; // saída: Min: 1, Max: 5
?>
